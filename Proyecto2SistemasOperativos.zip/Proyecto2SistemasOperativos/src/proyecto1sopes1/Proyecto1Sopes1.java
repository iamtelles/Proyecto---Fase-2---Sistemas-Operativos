package proyecto1sopes1;

public class Proyecto1Sopes1 {

    public static void main(String[] args) {
        //creacion de la ventana para que sea visible, configurado desde
        //main
        VentanaAplicacion frame = new VentanaAplicacion();
        
        frame.setVisible(true);
    }
    
}
